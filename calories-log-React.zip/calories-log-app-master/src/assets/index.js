const bgLogin = require('./login/login.png');
const logo = require('./login/logo.png');
const bgsignup = require('./login/bgsignup.png');
const logoRow = require('./login/logoRow.png');
const user = require('./navbar/user.png');
const fav = require('./navbar/fav.png');
const logOut = require('./navbar/logOut.png');
const introLeft = require('./home/introLeft.png');
const introRight = require('./home/introRight.png');
const partner = require('./home/partner.png');
const chef = require('./home/chef.png');
const baking = require('./home/baking.png');
const meal = require('./home/meal.png');
const list = require('./home/list.png');
const mental = require('./home/mental.png');
const bodyScale = require('./home/bodyScale.png');
const heartBeat = require('./home/heartBeat.png');
const scale = require('./aboutUs/scale.png');
const energy = require('./aboutUs/energy.png');
const smoothies = require('./aboutUs/smoothies.png');
const health = require('./aboutUs/health.png');
const happy = require('./aboutUs/happy.png');
const burger = require('./aboutUs/burger.png');
const bowl = require('./aboutUs/bowl.png');
const check = require('./premiumPlan/check.png');
const brain = require('./home/brain.png');
const apple = require('./home/apple.png');
const wa = require('./footer/wa.png');
const ig = require('./footer/instagram.png');
const email = require('./footer/email.png');
const phone = require('./footer/phone.png');
const eye = require('./article/eye.png');
const fruit = require('./article/fruit.png');
const meat = require('./article/meat.png');
const baby = require('./article/baby.png');
const smoothies2 = require('./article/smoothies.png');
const salad = require('./article/salad.png');
const smoothies3 = require('./article/smoothies3.png');
const bmi = require('./profile/bmi.png');
const Star5 = require('./review/5star.png');
<<<<<<< Updated upstream
const img1 = require('./home/img1.png');
const img2 = require('./home/img2.png');
const img3 = require('./home/img3.png');
const img4 = require('./home/img4.png');
const img5 = require('./home/img5.png');
const img6 = require('./home/img6.png');
const img7 = require('./home/img7.png');
const img8 = require('./home/img8.png');
const img9 = require('./home/img9.png');
const app1 = require('./home/app1.jpeg');
const app2 = require('./home/app2.jpg');
// const app3 = require('./home/app3.JPG');
const app4 = require('./home/app4.jpg');
const app5 = require('./home/app5.jpg');
const app6 = require('./home/app6.jpg');
const app7 = require('./home/app7.jpg');
const app8 = require('./home/app8.jpg');
const app9 = require('./home/app9.jpg');
const app10 = require('./home/app10.jpg');
=======
const snack1 = require ('./snack/snack1.png');
const snack2 = require ('./snack/snack2.png');
const snack3 = require ('./snack/snack3.png');
const snack4 = require ('./snack/snack4.png');
const snack5 = require ('./snack/snack5.png');
const snack6 = require ('./snack/snack6.png');
const snack7 = require ('./snack/snack7.png');
const snack8 = require ('./snack/snack8.png');
const snack9 = require ('./snack/snack9.png');
consts kcal = require ('./home/kcal.png');
consts heart = require ('./home/heart.png');
consts beverage1 = require ('./beverage/bev1.png');
consts beverage2 = require ('./beverage/bev2.png');
consts beverage3 = require ('./beverage/bev3.png');
consts beverage4 = require ('./beverage/bev4.png');
consts beverage5 = require ('./beverage/bev5.png');
consts beverage6 = require ('./beverage/bev6.png');
consts beverage7 = require ('./beverage/bev7.png');
consts beverage8 = require ('./beverage/bev8.png');
consts beverage9 = require ('./beverage/bev9.png');
>>>>>>> Stashed changes

module.exports = {
    logo, 
    bgsignup, 
    bgLogin,
    logoRow,
    user,
    fav,
    logOut,
    introLeft,
    introRight,
    partner,
    chef,
    meal,
    baking,
    list,
    mental,
    bodyScale,
    heartBeat,
    smoothies,
    health,
    happy,
    burger,
    scale, 
    bowl,
    energy,
    check,
    brain,
    apple,
    wa,
    ig,
    phone,
    email,
    eye,
    fruit,
    meat,
    baby,
    smoothies2,
    salad, 
    smoothies3,
    bmi,
    Star5,
<<<<<<< Updated upstream
    img1,
    img2,
    img3,
    img4,
    img5,
    img6,
    img7,
    img8,
    img9,
    app1,
    app2,
    app4,
    app5,
    app6,
    app7,
    app8,
    app9,
    app10
=======
    snack1,
    snack2,
    snack3,
    snack4,
    snack5,
    snack6,
    snack7,
    snack8,
    snack9,
    kcal,
    heart,
    beverage1,
    beverage2,
    beverage3,
    beverage4,
    beverage5,
    beverage6,
    beverage7,
    beverage8,
    beverage9
>>>>>>> Stashed changes
}