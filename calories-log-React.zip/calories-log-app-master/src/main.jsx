import React from 'react';
import Form from './components/signup/forms.jsx'

function Main (){
    return (
        <Form/>
    )
}

export default Main;